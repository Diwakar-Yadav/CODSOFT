
# Quote of the day 

**New Quote EVERY day** to **inspire and encourage you** to carpe diem- (seize the day!) We've found that reading positive quotes, each day, helps by delivering wisdom from those who have gone ahead of us. **Allow their wise words to motivate you every day of the week!**


## Features

- PWA
- Fast
- Fullscreen mode
- Cross platform

  
## Tech Stack

**Client:** HTML, CSS, JavaScript

  
## Demo

 - [Try Now](https://qod.shakiltech.com)

## Authors

- [@itxshakil](https://www.github.com/itxshakil)

  
## License

[MIT](https://choosealicense.com/licenses/mit/)

  
